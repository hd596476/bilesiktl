# BileşikTL

TL ile yurt dışı hisse ve ETF yatırımı yapanlar için ücretsiz hesaplayıcılar.

## Dosyalar

| Dosya | Ne işe yarar |
|---|---|
| `index.html` | Sitenin kendisi |
| `data/prices.json` | Hisse ve ETF fiyatları, geçmiş getiriler (her gün otomatik güncellenir) |
| `scripts/update_data.py` | Verileri çeken program |
| `.github/workflows/update-data.yml` | Programı her iş günü otomatik çalıştıran ayar |

---

## Kurulum (bir kerelik, yaklaşık 15 dakika)

### 1. Depo oluştur
1. GitHub'da sağ üstteki **+** → **New repository**.
2. Ad: `bilesiktl` · **Public** seç · **Create repository**.

### 2. Dosyaları yükle
1. İndirdiğin zip dosyasını bilgisayarında aç (sağ tık → Tümünü ayıkla).
2. Depo sayfasında **uploading an existing file** bağlantısına tıkla.
3. Açtığın klasörün **içindeki her şeyi** (`index.html`, `data`, `scripts`, `.github`, `README.md`) sürükleyip bırak.
4. Alttaki **Commit changes** düğmesine bas.

> `.github` klasörü yüklenmezse: **Add file → Create new file** de, dosya adına
> `.github/workflows/update-data.yml` yaz ve dosyanın içeriğini yapıştır.

### 3. Otomatik güncellemeye yazma izni ver
**Settings → Actions → General** → en altta **Workflow permissions** →
**Read and write permissions** seç → **Save**.

### 4. Veriyi ilk kez çek
1. Üstteki **Actions** sekmesi → soldan **Günlük veri güncelleme**.
2. Sağdaki **Run workflow** → yeşil **Run workflow**.
3. 10–20 dakika sürer. Yeşil tik görünce `data/prices.json` 1.000'den fazla sembolle dolmuş olur.

Bundan sonra her iş günü saat 01:30'da (İstanbul) kendiliğinden çalışır.

### 5. Siteyi yayına al
**Settings → Pages** → Source: **Deploy from a branch** → Branch: **main**, klasör: **/(root)** → **Save**.

1–2 dakika sonra site şu adreste açılır:
`https://KULLANICI-ADIN.github.io/bilesiktl/`

Canlı döviz kuru ve günlük fiyatlar bu adreste çalışır.

---

## Hesap yöntemi

- **Getiri beklentisi (CAPM)** = ABD 10 yıllık tahvil faizi + Beta × %4,5 piyasa risk primi.
- **Beta** = son 5 yılın aylık getirilerinin SPY'a göre betası, Bloomberg tarzı düzeltmeyle (0,67 × β + 0,33), 0,3 ile 2,5 arasında sınırlı.
- **Kötümser / iyimser senaryo** = beklenen getiri ∓ 1,28 × oynaklık ÷ √süre (olasılık dağılımının %10 ve %90 dilimleri).
- **Oynaklık** = son 5 yılın aylık getirilerinin yıllık standart sapması.
- **Geçmiş getiri** (1/3/5/10 yıl) sitede sadece bilgi olarak gösterilir, hesapta kullanılmaz.

Ayarlar `scripts/update_data.py` dosyasının başındadır (`RISK_PRIMI`, `YEDEK_FAIZ`, `BETA_ALT`, `BETA_UST`).

## Bilinmesi gerekenler

- Veriler Yahoo Finance'ten `yfinance` kütüphanesiyle çekilir. Bu resmî bir API değildir. Yahoo bir değişiklik yaparsa güncelleme durabilir. Bu durumda program eski veriyi korur ve site çalışmaya devam eder. Actions sekmesinde kırmızı çarpı görürsen haber ver.
- Sembol listesi S&P 500, S&P 400 ve Nasdaq-100'den her gün otomatik alınır. Liste dışı semboller `EK_SEMBOLLER` bölümüne eklenebilir.

**Yatırım tavsiyesi değildir.**
